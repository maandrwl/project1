from django.shortcuts import render

def home(request):
    return render(request,'home.html')

def course(request):
    return render(request,'course.html')

def assignment(request):
    return render(request,'assignment.html')

def viewscore(request):
    return render(request,'viewscore.html')

def login(request):
    return render(request,'login.html')

def asteacher(request):
    return render(request,'assignment-t.html')

def create(request):
    return render(request,'createassign.html')

def score(request):
    return render(request,'editscore.html')

def myprofile(request):
    return render(request,'profile.html')

def courseteacher(request):
    return render(request,'course-t.html')

def createcourse(request):
    return render(request,'newcourse.html')

# Create your views here.
